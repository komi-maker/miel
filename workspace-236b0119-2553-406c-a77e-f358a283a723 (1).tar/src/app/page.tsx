'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Star, Phone, Mail, MapPin, Heart, Hexagon, Package, Award, Loader2 } from 'lucide-react'

interface Product {
  id: number
  name: string
  description: string
  price: number
  weight: string
  badge: string
  rating: number
  category: string
  inStock: boolean
  image: string
}

interface Testimonial {
  id: number
  name: string
  text: string
  rating: number
  date: string
  verified: boolean
  location: string
}

export default function HoneySellerSite() {
  const [products, setProducts] = useState<Product[]>([])
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [loading, setLoading] = useState(true)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  })
  const [formStatus, setFormStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [formMessage, setFormMessage] = useState('')

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [productsRes, testimonialsRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/testimonials?verified=true&limit=3')
      ])

      if (productsRes.ok && testimonialsRes.ok) {
        const productsData = await productsRes.json()
        const testimonialsData = await testimonialsRes.json()
        
        setProducts(productsData.data || [])
        setTestimonials(testimonialsData.data || [])
      }
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setFormStatus('loading')
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const result = await response.json()

      if (result.success) {
        setFormStatus('success')
        setFormMessage(result.message || 'Message envoyé avec succès!')
        setFormData({ name: '', email: '', message: '' })
      } else {
        setFormStatus('error')
        setFormMessage(result.error || 'Erreur lors de l\'envoi')
      }
    } catch (error) {
      setFormStatus('error')
      setFormMessage('Erreur de connexion')
    }

    setTimeout(() => {
      setFormStatus('idle')
      setFormMessage('')
    }, 5000)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-amber-600 mx-auto mb-4" />
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Hexagon className="h-8 w-8 text-amber-600" />
              <span className="text-xl font-bold text-gray-900">Miel d'Exception</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#products" className="text-gray-700 hover:text-amber-600 transition-colors">Nos Miels</a>
              <a href="#about" className="text-gray-700 hover:text-amber-600 transition-colors">Notre Histoire</a>
              <a href="#testimonials" className="text-gray-700 hover:text-amber-600 transition-colors">Témoignages</a>
              <a href="#contact" className="text-gray-700 hover:text-amber-600 transition-colors">Contact</a>
            </div>
            <Button className="bg-amber-600 hover:bg-amber-700">
              Commander
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Le Goût Authentique de la
              <span className="text-amber-600"> Nature</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Découvrez nos miels artisanaux, récoltés avec passion dans le respect de l'environnement et de nos abeilles.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-amber-600 hover:bg-amber-700 text-lg px-8 py-3">
                Découvrir nos miels
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-3">
                Notre histoire
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Qualité Bio</h3>
              <p className="text-gray-600">Certification agriculture biologique, sans pesticides ni additifs.</p>
            </div>
            <div className="text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Artisanal</h3>
              <p className="text-gray-600">Chaque pot est rempli à la main avec soin et passion.</p>
            </div>
            <div className="text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Livraison Rapide</h3>
              <p className="text-gray-600">Expédition sous 48h dans toute la France.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nos Miels d'Exception</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Une sélection variée de miels uniques, chacun avec son caractère et ses bienfaits.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.slice(0, 4).map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                      {product.badge}
                    </Badge>
                    <div className="flex">
                      {[...Array(product.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  </div>
                  <CardTitle className="text-lg">{product.name}</CardTitle>
                  <CardDescription>{product.weight}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm mb-4">{product.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-bold text-amber-600">{product.price}€</span>
                    <Button 
                      size="sm" 
                      className="bg-amber-600 hover:bg-amber-700"
                      disabled={!product.inStock}
                    >
                      {product.inStock ? 'Ajouter' : 'Rupture'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Notre Passion, Votre Plaisir</h2>
              <p className="text-gray-600 mb-4">
                Depuis trois générations, notre famille perpétue la tradition apicole avec passion et respect. 
                Installés au cœur de la campagne française, nous élevons nos abeilles dans un environnement préservé, 
                loin de toute pollution.
              </p>
              <p className="text-gray-600 mb-6">
                Chaque récolte est un moment unique, où nous transformons avec soin le nectar butiné par nos abeilles 
                en un miel d'exception. Notre savoir-faire artisanal garantit une qualité incomparable et des saveurs authentiques.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-amber-50 rounded-lg">
                  <div className="text-3xl font-bold text-amber-600 mb-1">50+</div>
                  <div className="text-sm text-gray-600">Ruches</div>
                </div>
                <div className="text-center p-4 bg-amber-50 rounded-lg">
                  <div className="text-3xl font-bold text-amber-600 mb-1">15</div>
                  <div className="text-sm text-gray-600">Années d'expérience</div>
                </div>
              </div>
            </div>
            <div className="bg-amber-100 rounded-lg p-8 text-center">
              <Hexagon className="h-24 w-24 text-amber-600 mx-auto mb-4" />
              <p className="text-lg text-gray-700 italic">
                "L'abeille est plus sage que l'architecte, car elle construit sa ruche sans aucun conseil."
              </p>
              <p className="text-sm text-gray-600 mt-2">- Proverbe</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Ce Que Disent Nos Clients</h2>
            <p className="text-xl text-gray-600">Des milliers de clients satisfaits nous font confiance chaque jour.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  {testimonial.location && (
                    <p className="text-sm text-gray-500">{testimonial.location}</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Contactez-Nous</h2>
            <p className="text-xl text-gray-600">Une question ? Une commande spéciale ? Nous sommes là pour vous.</p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nom complet
                  </label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Votre nom"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="votre@email.com"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    placeholder="Votre message..."
                    rows={4}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-amber-600 hover:bg-amber-700" disabled={formStatus === 'loading'}>
                  {formStatus === 'loading' ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Envoi en cours...
                    </>
                  ) : (
                    'Envoyer le message'
                  )}
                </Button>
                {formMessage && (
                  <div className={`text-sm text-center p-2 rounded ${
                    formStatus === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {formMessage}
                  </div>
                )}
              </form>
            </div>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <Phone className="h-6 w-6 text-amber-600 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Téléphone</h3>
                  <p className="text-gray-600">+33 6 12 34 56 78</p>
                  <p className="text-sm text-gray-500">Du lundi au samedi, 9h-18h</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <Mail className="h-6 w-6 text-amber-600 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Email</h3>
                  <p className="text-gray-600">contact@mielexception.fr</p>
                  <p className="text-sm text-gray-500">Réponse sous 24h</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <MapPin className="h-6 w-6 text-amber-600 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">Adresse</h3>
                  <p className="text-gray-600">12 Route des Abeilles</p>
                  <p className="text-gray-600">84200 Bonnieux</p>
                  <p className="text-sm text-gray-500">France</p>
                </div>
              </div>
              <div className="bg-amber-50 p-6 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Visitez notre rucher</h3>
                <p className="text-gray-600 text-sm">
                  Découvrez notre métier et dégustez nos miels sur place. 
                  Visites possibles sur rendez-vous du mercredi au dimanche.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Hexagon className="h-6 w-6 text-amber-400" />
                <span className="text-lg font-bold">Miel d'Exception</span>
              </div>
              <p className="text-gray-400 text-sm">
                Le miel artisanal au cœur de la tradition française.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Produits</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-amber-400">Miel de Fleurs</a></li>
                <li><a href="#" className="hover:text-amber-400">Miel de Châtaignier</a></li>
                <li><a href="#" className="hover:text-amber-400">Miel de Lavande</a></li>
                <li><a href="#" className="hover:text-amber-400">Coffrets Cadeaux</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Informations</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-amber-400">Notre Histoire</a></li>
                <li><a href="#" className="hover:text-amber-400">Certification Bio</a></li>
                <li><a href="#" className="hover:text-amber-400">Livraison</a></li>
                <li><a href="#" className="hover:text-amber-400">Mentions Légales</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Newsletter</h4>
              <p className="text-gray-400 text-sm mb-4">
                Recevez nos actualités et offres spéciales.
              </p>
              <div className="flex space-x-2">
                <Input 
                  type="email" 
                  placeholder="Votre email" 
                  className="bg-gray-800 border-gray-700 text-white"
                />
                <Button size="sm" className="bg-amber-600 hover:bg-amber-700">
                  OK
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 Miel d'Exception. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}