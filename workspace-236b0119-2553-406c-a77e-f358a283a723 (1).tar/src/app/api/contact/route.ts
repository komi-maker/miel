import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Mock storage for contact messages
const contactMessages: any[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate required fields
    if (!body.name || !body.email || !body.message) {
      return NextResponse.json(
        { success: false, error: 'Tous les champs sont obligatoires' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(body.email)) {
      return NextResponse.json(
        { success: false, error: 'Format d\'email invalide' },
        { status: 400 }
      )
    }

    // Create contact message
    const contactMessage = {
      id: contactMessages.length + 1,
      name: body.name,
      email: body.email,
      message: body.message,
      phone: body.phone || '',
      subject: body.subject || 'Demande de contact',
      createdAt: new Date().toISOString(),
      status: 'new'
    }

    // Store message (in production, save to database)
    contactMessages.push(contactMessage)

    // Send notification email using AI to generate a professional response
    try {
      const zai = await ZAI.create()
      
      const emailContent = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Tu es un assistant professionnel pour une entreprise de miel artisanal. Génère une réponse de confirmation courte et chaleureuse pour un client qui a pris contact.'
          },
          {
            role: 'user',
            content: `Nom: ${body.name}\nEmail: ${body.email}\nMessage: ${body.message}\n\nGénère une réponse de confirmation professionnelle et chaleureuse.`
          }
        ],
        max_tokens: 200,
        temperature: 0.7
      })

      const aiResponse = emailContent.choices[0]?.message?.content || 'Merci pour votre message. Nous vous répondrons dans les plus brefs délais.'

      return NextResponse.json({
        success: true,
        message: 'Message envoyé avec succès',
        data: {
          id: contactMessage.id,
          autoReply: aiResponse
        }
      })
    } catch (aiError) {
      console.error('AI service error:', aiError)
      
      // Fallback response if AI fails
      return NextResponse.json({
        success: true,
        message: 'Message envoyé avec succès',
        data: {
          id: contactMessage.id,
          autoReply: 'Merci pour votre message. Nous vous répondrons dans les plus brefs délais.'
        }
      })
    }
  } catch (error) {
    console.error('Contact form error:', error)
    return NextResponse.json(
      { success: false, error: 'Erreur lors de l\'envoi du message' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')

    let filteredMessages = contactMessages

    if (status) {
      filteredMessages = filteredMessages.filter(m => m.status === status)
    }

    return NextResponse.json({
      success: true,
      data: filteredMessages,
      total: filteredMessages.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch contact messages' },
      { status: 500 }
    )
  }
}