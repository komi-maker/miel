import { NextRequest, NextResponse } from 'next/server'

// Mock database for testimonials
const testimonials = [
  {
    id: 1,
    name: "Marie Dubois",
    text: "Le meilleur miel que j'ai jamais goûté ! Frais, naturel et plein de saveurs.",
    rating: 5,
    date: "2024-01-15",
    verified: true,
    location: "Paris"
  },
  {
    id: 2,
    name: "Pierre Martin",
    text: "Je commande depuis 3 ans, la qualité est toujours exceptionnelle. Vraiment du miel artisanal.",
    rating: 5,
    date: "2024-01-10",
    verified: true,
    location: "Lyon"
  },
  {
    id: 3,
    name: "Sophie Laurent",
    text: "Un apiculteur passionné qui transmet son amour des abeilles dans chaque pot.",
    rating: 5,
    date: "2024-01-08",
    verified: true,
    location: "Marseille"
  },
  {
    id: 4,
    name: "Jean Petit",
    text: "Excellent rapport qualité-prix. Le miel de châtaignier est divin !",
    rating: 4,
    date: "2024-01-05",
    verified: true,
    location: "Bordeaux"
  },
  {
    id: 5,
    name: "Claire Bernard",
    text: "J'ai offert le coffret dégustation en cadeau, c'était un succès !",
    rating: 5,
    date: "2023-12-28",
    verified: true,
    location: "Toulouse"
  }
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const rating = searchParams.get('rating')
    const verified = searchParams.get('verified')
    const limit = searchParams.get('limit')

    let filteredTestimonials = testimonials

    if (rating) {
      filteredTestimonials = filteredTestimonials.filter(t => t.rating >= parseInt(rating))
    }

    if (verified === 'true') {
      filteredTestimonials = filteredTestimonials.filter(t => t.verified)
    }

    if (limit) {
      filteredTestimonials = filteredTestimonials.slice(0, parseInt(limit))
    }

    // Sort by date (most recent first)
    filteredTestimonials.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    return NextResponse.json({
      success: true,
      data: filteredTestimonials,
      total: filteredTestimonials.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch testimonials' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate required fields
    if (!body.name || !body.text || !body.rating) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Validate rating
    if (body.rating < 1 || body.rating > 5) {
      return NextResponse.json(
        { success: false, error: 'Rating must be between 1 and 5' },
        { status: 400 }
      )
    }

    // Create new testimonial
    const newTestimonial = {
      id: testimonials.length + 1,
      name: body.name,
      text: body.text,
      rating: parseInt(body.rating),
      date: new Date().toISOString().split('T')[0],
      verified: false, // New testimonials need verification
      location: body.location || ''
    }

    // In production, save to database and send verification email
    testimonials.push(newTestimonial)

    return NextResponse.json({
      success: true,
      message: 'Testimonial submitted successfully. It will be visible after verification.',
      data: newTestimonial
    }, { status: 201 })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to create testimonial' },
      { status: 500 }
    )
  }
}