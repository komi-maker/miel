import { NextRequest, NextResponse } from 'next/server'

// Mock database - in production, this would come from a real database
const products = [
  {
    id: 1,
    name: "Miel de Fleurs Sauvages",
    description: "Un miel délicat aux notes florales complexes, récolté dans nos prairies montagneuses.",
    price: 12,
    weight: "500g",
    badge: "Best-seller",
    rating: 5,
    category: "fleurs",
    inStock: true,
    image: "/api/placeholder/300/200"
  },
  {
    id: 2,
    name: "Miel de Châtaignier",
    description: "Miel robuste et aromatique avec une saveur boisée unique, parfait pour les plats salés.",
    price: 14,
    weight: "500g",
    badge: "Bio",
    rating: 5,
    category: "chataignier",
    inStock: true,
    image: "/api/placeholder/300/200"
  },
  {
    id: 3,
    name: "Miel de Lavande",
    description: "Miel parfumé aux douces notes de lavande de Provence, idéal en tisane.",
    price: 13,
    weight: "500g",
    badge: "Limited",
    rating: 4,
    category: "lavande",
    inStock: true,
    image: "/api/placeholder/300/200"
  },
  {
    id: 4,
    name: "Miel d'Acacia",
    description: "Miel clair et doux, cristallise très lentement, parfait pour les enfants.",
    price: 11,
    weight: "500g",
    badge: "Classique",
    rating: 5,
    category: "acacia",
    inStock: true,
    image: "/api/placeholder/300/200"
  },
  {
    id: 5,
    name: "Miel de Forêt",
    description: "Miel sombre et puissant aux saveurs complexes de sous-bois.",
    price: 15,
    weight: "500g",
    badge: "Premium",
    rating: 5,
    category: "foret",
    inStock: false,
    image: "/api/placeholder/300/200"
  },
  {
    id: 6,
    name: "Coffret Dégustation",
    description: "Un assortiment de 3 miels différents pour découvrir nos saveurs.",
    price: 35,
    weight: "3x250g",
    badge: "Cadeau",
    rating: 5,
    category: "coffret",
    inStock: true,
    image: "/api/placeholder/300/200"
  }
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const inStock = searchParams.get('inStock')

    let filteredProducts = products

    if (category) {
      filteredProducts = filteredProducts.filter(p => p.category === category)
    }

    if (inStock === 'true') {
      filteredProducts = filteredProducts.filter(p => p.inStock)
    }

    return NextResponse.json({
      success: true,
      data: filteredProducts,
      total: filteredProducts.length
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch products' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate required fields
    if (!body.name || !body.price || !body.description) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Create new product (in production, save to database)
    const newProduct = {
      id: products.length + 1,
      ...body,
      rating: 0,
      inStock: true,
      image: "/api/placeholder/300/200"
    }

    products.push(newProduct)

    return NextResponse.json({
      success: true,
      data: newProduct
    }, { status: 201 })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to create product' },
      { status: 500 }
    )
  }
}