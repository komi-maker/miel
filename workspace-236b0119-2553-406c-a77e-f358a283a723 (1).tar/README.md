# 🍯 Miel d'Exception - Site Web d'Apiculteur

Un site web moderne et élégant pour un vendeur de miel artisanal, construit avec Next.js 15, TypeScript, et Tailwind CSS.

## 🌟 Caractéristiques

- **Design Responsive** : Adapté pour mobile, tablette et desktop
- **Interface Moderne** : Utilisation de shadcn/ui et Tailwind CSS
- **Produits Dynamiques** : Gestion des produits via API
- **Formulaire de Contact** : Avec validation et réponses AI automatiques
- **Témoignages Clients** : Système d'avis vérifiés
- **Performance Optimisée** : Next.js 15 avec App Router

## 🛠️ Stack Technique

- **Framework** : Next.js 15 avec App Router
- **Langage** : TypeScript 5
- **Styling** : Tailwind CSS 4 + shadcn/ui
- **ICônes** : Lucide React
- **AI** : z-ai-web-dev-sdk pour les réponses automatiques
- **Déploiement** : Compatible Vercel, Netlify, etc.

## 📦 Structure du Projet

```
miel-exception/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── products/     # API pour les produits
│   │   │   ├── contact/      # API pour les contacts
│   │   │   └── testimonials/ # API pour les témoignages
│   │   ├── page.tsx          # Page d'accueil principale
│   │   └── layout.tsx        # Layout du site
│   ├── components/
│   │   └── ui/               # Composants shadcn/ui
│   └── lib/
│       └── db.ts             # Configuration base de données
├── public/
│   ├── honey-hero.jpg        # Image hero
│   └── favicon.ico           # Favicon
├── prisma/
│   └── schema.prisma         # Schéma Prisma
└── package.json
```

## 🚀 Installation

1. **Cloner le repository**
   ```bash
   git clone <repository-url>
   cd miel-exception
   ```

2. **Installer les dépendances**
   ```bash
   npm install
   ```

3. **Configurer les variables d'environnement**
   ```bash
   cp .env.example .env.local
   ```
   Éditez `.env.local` avec vos clés API :
   ```env
   ZAI_API_KEY=votre_clé_zai
   DATABASE_URL=votre_url_database
   ```

4. **Initialiser la base de données**
   ```bash
   npx prisma generate
   npx prisma db push
   ```

5. **Démarrer le serveur de développement**
   ```bash
   npm run dev
   ```

   Visitez `http://localhost:3000` pour voir le site.

## 📝 Scripts Disponibles

- `npm run dev` - Serveur de développement
- `npm run build` - Build pour production
- `npm run start` - Serveur de production
- `npm run lint` - Linter ESLint
- `npm run db:push` - Synchroniser la base de données

## 🎨 Personnalisation

### Couleurs et Thème
Les couleurs sont définies dans les classes Tailwind :
- **Primaire** : `amber-600` (ambre/or)
- **Arrière-plan** : `amber-50` à `orange-50` (dégradé)

### Produits
Modifiez les produits dans `src/app/api/products/route.ts` ou utilisez une base de données.

### Images
Remplacez les images dans le dossier `public/` :
- `honey-hero.jpg` : Image hero
- `favicon.ico` : Icône du site

## 🌐 Déploiement

### Vercel (Recommandé)
1. Connectez votre repository GitHub à Vercel
2. Configurez les variables d'environnement
3. Déployez automatiquement

### Netlify
1. Build command: `npm run build`
2. Publish directory: `.next`
3. Configurez les variables d'environnement

### Autres Plateformes
Le site est compatible avec toute plateforme supportant Next.js.

## 📱 Fonctionnalités

### Page d'Accueil
- Hero section avec appel à l'action
- Présentation des produits vedettes
- Section sur l'histoire de l'apiculteur
- Témoignages clients
- Formulaire de contact

### API Routes
- **GET/POST /api/products** : Gestion des produits
- **POST /api/contact** : Envoi des messages de contact
- **GET/POST /api/testimonials** : Gestion des témoignages

### Intelligence Artificielle
Le formulaire de contact utilise l'IA pour générer des réponses automatiques personnalisées.

## 🔧 Configuration

### Base de Données
Le projet utilise Prisma avec SQLite par défaut. Pour changer :
1. Modifiez `prisma/schema.prisma`
2. Mettez à jour `DATABASE_URL` dans `.env.local`
3. Lancez `npx prisma db push`

### API Keys
Pour utiliser l'IA :
1. Obtenez une clé API de z-ai-web-dev-sdk
2. Ajoutez `ZAI_API_KEY` à vos variables d'environnement

## 🤝 Contribuer

1. Fork le projet
2. Créez une branche (`git checkout -b feature/nouvelle-fonctionnalité`)
3. Commitez vos changements (`git commit -am 'Ajout nouvelle fonctionnalité'`)
4. Push vers la branche (`git push origin feature/nouvelle-fonctionnalité`)
5. Créez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus de détails.

## 📞 Support

Pour toute question ou problème :
- Créez une issue sur GitHub
- Contactez via le formulaire du site

---

**Développé avec ❤️ et Next.js 15**