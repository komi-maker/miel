# 📋 Guide de Déploiement - Miel d'Exception

Ce guide vous explique comment déployer le site "Miel d'Exception" sur différentes plateformes.

## 🚀 Prérequis

- Node.js 18+ installé
- Compte sur une plateforme de déploiement (Vercel, Netlify, etc.)
- Clé API Z-AI (pour les réponses automatiques)

## 📦 Fichiers du Projet

L'archive complète `miel-exception-complete.tar.gz` contient tous les fichiers nécessaires :

```
miel-exception/
├── README.md                 # Documentation complète
├── DEPLOYMENT.md            # Ce guide
├── LICENSE                  # Licence MIT
├── package.json             # Dépendances et scripts
├── next.config.js           # Configuration Next.js
├── tailwind.config.js       # Configuration Tailwind
├── tsconfig.json            # Configuration TypeScript
├── .env.example             # Variables d'environnement
├── .gitignore               # Fichiers à ignorer
├── deploy.sh                # Script de déploiement
├── src/
│   ├── app/
│   │   ├── page.tsx         # Page d'accueil
│   │   ├── layout.tsx       # Layout du site
│   │   └── api/             # API routes
│   │       ├── products/
│   │       ├── contact/
│   │       └── testimonials/
│   └── components/ui/       # Composants UI
├── public/
│   ├── honey-hero.jpg       # Image hero
│   └── favicon.ico          # Favicon
└── prisma/
    └── schema.prisma        # Schéma base de données
```

## 🌐 Déploiement sur Vercel (Recommandé)

### 1. Préparation

1. **Téléchargez et décompressez** l'archive
2. **Créez un repository GitHub** avec les fichiers
3. **Connectez votre compte Vercel** à GitHub

### 2. Configuration

1. **Importez le projet** dans Vercel
2. **Configurez les variables d'environnement** :
   ```
   ZAI_API_KEY=votre_clé_api_zai
   DATABASE_URL=file:./dev.db
   NEXTAUTH_URL=https://votre-domaine.vercel.app
   NEXTAUTH_SECRET=votre_secret_aleatoire
   ```

### 3. Déploiement

```bash
# Installation locale (optionnel)
npm install

# Build de test
npm run build

# Déploiement via Vercel CLI
vercel --prod
```

## 🌐 Déploiement sur Netlify

### 1. Préparation

1. **Téléchargez et décompressez** l'archive
2. **Créez un repository GitHub**
3. **Connectez Netlify à GitHub**

### 2. Configuration

Dans les paramètres Netlify :

**Build settings:**
- Build command: `npm run build`
- Publish directory: `.next`

**Environment variables:**
```
ZAI_API_KEY=votre_clé_api_zai
DATABASE_URL=file:./dev.db
NEXTAUTH_URL=https://votre-domaine.netlify.app
NEXTAUTH_SECRET=votre_secret_aleatoire
```

### 3. Déploiement

```bash
# Installation locale
npm install

# Build
npm run build

# Déploiement via Netlify CLI
netlify deploy --prod --dir=.next
```

## 🌐 Déploiement sur un VPS (Ubuntu/Debian)

### 1. Préparation du serveur

```bash
# Mise à jour du serveur
sudo apt update && sudo apt upgrade -y

# Installation de Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Installation de PM2
sudo npm install -g pm2
```

### 2. Déploiement

```bash
# Clone du repository
git clone <votre-repository-url>
cd miel-exception

# Installation des dépendances
npm install

# Configuration des variables d'environnement
cp .env.example .env
# Éditez .env avec vos valeurs

# Build de l'application
npm run build

# Démarrage avec PM2
pm2 start npm --name "miel-exception" -- start

# Configuration du redémarrage automatique
pm2 startup
pm2 save
```

### 3. Configuration Nginx (optionnel)

```nginx
server {
    listen 80;
    server_name votre-domaine.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🔧 Configuration des Variables d'Environnement

### Obligatoires

```env
# Z-AI Web Dev SDK
ZAI_API_KEY=votre_clé_api_zai

# Base de données
DATABASE_URL=file:./dev.db

# NextAuth
NEXTAUTH_URL=https://votre-domaine.com
NEXTAUTH_SECRET=votre_secret_32_caracteres_min
```

### Optionnelles

```env
# Configuration du site
SITE_NAME=Miel d'Exception
SITE_URL=https://votre-domaine.com

# Email (notifications)
SMTP_HOST=smtp.votreserveur.com
SMTP_PORT=587
SMTP_USER=votre_email@exemple.com
SMTP_PASS=votre_mot_de_passe

# Analytics
GOOGLE_ANALYTICS_ID=GA-XXXXXXXXX
```

## 🧪 Tests avant déploiement

```bash
# Installation des dépendances
npm install

# Vérification du code
npm run lint

# Vérification des types
npm run type-check

# Build de test
npm run build

# Démarrage en mode développement
npm run dev
```

## 📝 Script de Déploiement Automatisé

Utilisez le script inclus :

```bash
# Rendre le script exécutable
chmod +x deploy.sh

# Déploiement pour production
./deploy.sh production

# Déploiement pour staging
./deploy.sh staging
```

## 🐛 Dépannage

### Problèmes courants

1. **Build échoue**
   - Vérifiez les versions de Node.js
   - Nettoyez le cache : `rm -rf .next node_modules && npm install`

2. **Variables d'environnement**
   - Assurez-vous que toutes les variables requises sont configurées
   - Vérifiez les noms exacts des variables

3. **Base de données**
   - Pour la production, utilisez une base de données externe (PostgreSQL, MySQL)
   - Mettez à jour `DATABASE_URL` en conséquence

4. **Images ne s'affichent pas**
   - Vérifiez la configuration `next.config.js`
   - Assurez-vous que les domaines sont autorisés

### Logs et monitoring

```bash
# Logs PM2 (VPS)
pm2 logs miel-exception

# Logs Vercel
vercel logs

# Logs Netlify
netlify functions:logs
```

## 📞 Support

Pour toute question sur le déploiement :

1. Consultez la [documentation Next.js](https://nextjs.org/docs)
2. Vérifiez les logs d'erreur
3. Créez une issue sur le repository GitHub

---

**Bon déploiement ! 🚀**