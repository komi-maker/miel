#!/bin/bash

# Script de déploiement pour Miel d'Exception
# Usage: ./deploy.sh [environment]

set -e

# Couleurs pour les logs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Fonction pour afficher les logs
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

warning() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

# Vérifier l'environnement
ENVIRONMENT=${1:-production}
log "Déploiement pour l'environnement: $ENVIRONMENT"

# Vérifier si Node.js est installé
if ! command -v node &> /dev/null; then
    error "Node.js n'est pas installé. Veuillez l'installer avant de continuer."
fi

# Vérifier si npm est installé
if ! command -v npm &> /dev/null; then
    error "npm n'est pas installé. Veuillez l'installer avant de continuer."
fi

# Nettoyer les installations précédentes
log "Nettoyage des installations précédentes..."
rm -rf .next node_modules

# Installer les dépendances
log "Installation des dépendances..."
npm install

# Générer Prisma Client
log "Génération de Prisma Client..."
npm run db:generate

# Pousser le schéma de la base de données
if [ "$ENVIRONMENT" = "production" ]; then
    log "Pousser le schéma de la base de données..."
    npm run db:push
fi

# Vérifier le code
log "Vérification du code avec ESLint..."
npm run lint

# Vérifier les types TypeScript
log "Vérification des types TypeScript..."
npm run type-check

# Build de l'application
log "Build de l'application..."
npm run build

# Vérifier si le build a réussi
if [ ! -d ".next" ]; then
    error "Le build a échoué. Le dossier .next n'a pas été créé."
fi

log "Build terminé avec succès!"

# Instructions pour le déploiement
case $ENVIRONMENT in
    "production")
        log "Pour déployer en production:"
        log "1. Configurez vos variables d'environnement"
        log "2. Déployez sur Vercel: vercel --prod"
        log "3. Ou déployez sur Netlify: netlify deploy --prod --dir=.next"
        ;;
    "staging")
        log "Pour déployer en staging:"
        log "1. Déployez sur Vercel: vercel"
        log "2. Ou déployez sur Netlify: netlify deploy --dir=.next"
        ;;
    *)
        warning "Environnement non reconnu: $ENVIRONMENT"
        ;;
esac

log "Déploiement préparé avec succès!"
log "N'oubliez pas de configurer vos variables d'environnement avant le déploiement final."